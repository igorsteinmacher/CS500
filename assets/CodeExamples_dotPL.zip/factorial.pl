factorial(0, 1). /* Fact: factorial of 0 is 1*/

factorial(N, Result) :- 
			M is N - 1, 			/* If variable M is assigned to N-1 */
			factorial(M, SubRes),	/* and if the factorial of M is SubRes */
			Result is N * SubRes.	/* and if Result is assigned to N*SubRes */
/* then, the factorial of N is result */


start(Fact):- 
       write('Number?'), read(N),
       factorial(N,Fact).