male(john).		
male(dante).
female(ana).
female(alice).
parent(john,alice).
parent(ana,alice).
parent(john,dante).
parent(ana,dante).