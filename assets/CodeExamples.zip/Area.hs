squareArea :: Double -> Double
squareArea side = side*side

rectangleArea :: Double -> Double -> Double
rectangleArea side1 side2 = if side1 == side2 
   ;then squareArea side1
   ;else side1*side2

rectangleArea2 :: Double -> Double -> Double
rectangleArea2 side1 side2 
   | side1 == side2 = squareArea side1
   | otherwise = side1 * side2
