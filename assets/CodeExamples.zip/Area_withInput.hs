-- this is the definition of the function
-- function name: squareArea, receives 1 parameter (a Double)
-- and returns a Double
squareArea :: Double -> Double 
-- this is the body of the function. Function squareArea gets
-- side as the input, and returns side*side
-- functions are FIRST CLASS CITIZEN
squareArea side = side*side


-- this is the definition of the function rectangleArea
-- it receives 2 parameters (both Double) and returns a Double
rectangleArea :: Double -> Double -> Double
-- in this case we have two potential conditions
rectangleArea side1 side2 = 
   -- if the two sides have the same value, we call squareArea side1
   if side1 == side2 
   then 
      squareArea side1
   -- if the two sides are different, we go ahead and calculate side1*side2
   else 
      side1*side2

rectangleArea2 :: Double -> Double -> Double
rectangleArea2 side1 side2 
   | side1 == side2 = squareArea side1
   | otherwise = side1 * side2

main = do 
   -- printing something on the screen
   putStrLn "Side 1: "  
   -- getting input from the user and assigning to side1
   side1 <- getLine
   putStrLn "Side 2: "  
   -- getting input from the user and assigning to side2
   side2 <- getLine
   putStrLn ("Area = " ++ show (rectangleArea (read side1) (read side2)))
